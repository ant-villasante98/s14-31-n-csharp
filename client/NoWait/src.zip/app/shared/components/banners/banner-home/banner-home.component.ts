import { Component } from '@angular/core';

@Component({
  selector: 'app-banner-home',
  standalone: true,
  imports: [],
  templateUrl: './banner-home.component.html',
  styleUrl: './banner-home.component.css'
})
export class BannerHomeComponent {

}
